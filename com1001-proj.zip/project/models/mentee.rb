#mentee users with the ability to check for valid login (or create a new user)
require "time_difference"
class Mentee < Sequel::Model
    
    def validate
        super
        errors.add("username", "cannot be empty") if username.empty?
        errors.add("psw", "cannot be empty") if psw.empty?
    end
    
    def load(params)
        #self.id = params.fetch("id", "").strip
        self.name = params.fetch("name", "").strip
        self.study_year = params.fetch("study_year", "").strip
        self.course = params.fetch("course", "").strip
        self.instrument = params.fetch("instrument", "").strip
        self.psw = params.fetch("psw", "").strip
        self.mail = params.fetch("mail", "").strip
        #self.mentor_email = params.fetch("mentor_email", "").strip
        self.username = params.fetch("username", "").strip
        self.date_of_birth = params.fetch("date_of_birth", "").strip
        #self.request_username = params.fetch("request_username", "").strip
        self.active = params.fetch("active", "1").strip
   end
    
   def exist?
        other_mentee = Mentee.first(username: username)
        !other_mentee.nil? && other_mentee.psw == psw
   end
    
   def in_db?
      other_mentee_username = Mentee.first(username: username)
      other_mentee_mail = Mentee.first(mail: mail)
      other_mentor_username = Mentor.first(username: username)
      other_mentor_mail = Mentor.first(mail: mail)
      !other_mentee_mail.nil? || !other_mentee_username.nil? || !other_mentor_username.nil? || !other_mentor_mail.nil?
   end
    
   def user
       logged = self.username
       return logged
   end
    
   def ban
       self.active = "0"
   end
    
  def unban
      self.active = "1"
  end
    
   #Putting the requested mentor's ID into mentee
   def request(mentorID)
       self.request_username = mentorID
   end
    
   def delete_request
       self.request_username = nil
   end
    
   def requested_mentor_exists
      if self.request_username == nil
          return false
      elsif self.request_username == ""
          return false
      else
          return true
     end
   end
    
   def self.id_exists?(id)
      return false if Mentee[id].nil?

      true
    end
end
