
class Request < Sequel::Model
    
    def load(params)
        self.type = params.fetch("type", "").strip
        self.date = params.fetch("date", "").strip
        self.content = params.fetch("content", "").strip
        self.completed = params.fetch("completed", "0").strip
        self.user_type = params.fetch("user_type", "").strip
        self.user_id = params.fetch("user_id", "").strip
    end
    
    def complete 
        self.completed = "1"
    end
    
end