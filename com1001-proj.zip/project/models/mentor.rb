#mentor users with the ability to check for valid login (or create a new user?)

class Mentor < Sequel::Model
    
    def validate
        super
        errors.add("username", "cannot be empty") if username.empty?
        errors.add("psw", "cannot be empty") if psw.empty?
   end
    
   def load(params)
        #self.id = params.fetch("id", "").strip
        self.name = params.fetch("name", "").strip
        self.date_of_birth = params.fetch("date_of_birth", "").strip
        self.gender = params.fetch("gender", "").strip
        self.instruments = params.fetch("instruments", "").strip
        self.graduated_uni = params.fetch("graduated_uni", "").strip
        self.experience = params.fetch("experience", "").strip
        self.mail = params.fetch("mail", "").strip
        self.psw = params.fetch("psw", "").strip
        self.admin = params.fetch("admin", "0").strip
        self.mentor = params.fetch("mentor", "1").strip
        self.username = params.fetch("username", "").strip
        self.active = params.fetch("active", "1").strip
   end
    
  def admin_completion
      self.admin = "1"
  end
  
    
  def mentor_disable
      self.mentor = "0"
  end
    
  def mentor_enable
      self.mentor = "1"
  end  
    
  def ban
      self.active = "0"
  end
    
  def unban
      self.active = "1"
  end
    
   def user
       return self.username
   end
    
   def exist?
        other_mentor = Mentor.first(username: username)
        !other_mentor.nil? && other_mentor.psw == psw
   end
   
   def in_db?
      other_mentor_username = Mentor.first(username: username)
      other_mentor_mail = Mentor.first(mail: mail)
      other_mentee_username = Mentee.first(username: username)
      other_mentee_mail = Mentee.first(mail: mail)
      !other_mentee_mail.nil? || !other_mentee_username.nil? || !other_mentor_username.nil? || !other_mentor_mail.nil?
   end
    
    def self.id_exists?(id)
      return false if Mentee[id].nil?

      true
    end
    
end

