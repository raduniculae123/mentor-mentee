#Testing controller access
RSpec.describe "Admin controller test" do
    #include Rack::Test::Methods
    
    def app
        Sinatra::Application
    end
    
    #Main access pages
    describe "GET /" do
        it "has a status code of 302 (redirect)" do
            get "/"
            expect(last_response.status).to eq(302)
        end
    end
    
    describe "GET /sign-in-mentee" do
        it "has a status code of 200 (OK)" do
            get "/sign-in-mentee"
            expect(last_response.status).to eq(200)
        end
        
        it "shows mentee login page" do
            get "/sign-in-mentee"
            expect(last_response.body).to include("Login")
            expect(last_response.body).to include("Mentee")
        end
    end
    
    describe "GET /sign-in-mentor" do
        it "has a status code of 200 (OK)" do
            get "/sign-in-mentor"
            expect(last_response.status).to eq(200)
        end
        
        it "shows mentor login page" do
            get "/sign-in-mentor"
            expect(last_response.body).to include("Login")
            expect(last_response.body).to include("Mentor")
        end
    end
    
    describe "GET /register" do
        it "has a status code of 200 (OK)" do
            get "/register"
            expect(last_response.status).to eq(200)
        end
        
        it "shows register page" do
            get "/register"
            expect(last_response.body).to include("Registration")
        end
    end
    
    describe "GET /reset-password" do
        it "has a status code of 200 (OK)" do
            get "/reset-password"
            expect(last_response.status).to eq(200)
        end
        
        it "shows reset password page" do
            get "/reset-password"
            expect(last_response.body).to include("Reset Password")
        end
    end
end
