#Testing mentee model
RSpec.describe Mentee do
     
    #Methods
    describe "#ban" do
        it "bans the mentee" do
            testMentee = Mentee.new
            testMentee.ban
            expect(testMentee.active).to eq(0)
        end
    end
    
    describe "#unban" do
        it "bans the mentee" do
            testMentee = Mentee.new
            testMentee.unban
            expect(testMentee.active).to eq(1)
        end
    end
    
    describe "#id_exists?" do
        it "check for mentee with id" do
            expect(Mentee.id_exists?(1)).to eq(true)
        end

        it "check for mentee without id" do
            expect(Mentee.id_exists?(99)).to eq(false)
        end
    end
end
