require_relative "../spec_helper"

describe "info input mentee" do

    #Testing features
    it "works when info is inputted" do
        visit "/sign-in-mentee"
        test_mentee_sign_in("mentee1", "mentee1")
        click_link "Profile"
        click_link "Edit Info"
        fill_in "name", with: "name mentee 1"
        click_button "submit"
        expect(page).to have_content "name mentee 1"
    end
    
end

describe "info input mentor" do

    #Testing features
    it "works when info is inputted" do
        visit "/sign-in-mentor"
        test_mentor_sign_in("mentor1", "mentor1")
        click_link "Profile"
        click_link "Edit Info"
        fill_in "name", with: "name mentor 1"
        click_button "submit"
        expect(page).to have_content "name mentor 1"
    end
    
end
