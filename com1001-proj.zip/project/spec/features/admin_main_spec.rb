require_relative "../spec_helper"

describe "admin main page" do
    
    before(:each) do
        test_admin_sign_in("admin", "admin")
    end
    
    it "report link works" do
        click_link "Reports"
        expect(page).to have_content "Reports"
    end
    
    it "mentee list link works" do
        click_link "Mentee List"
        expect(page).to have_content "All Mentees"
    end
    
    it "mentor list link works" do
        click_link "Mentor List"
        expect(page).to have_content "All Mentors"
    end
    
    it "banned list link works" do
        click_link "Banned List"
        expect(page).to have_content "Banned Mentees"
    end
    
    it "admin creation link works" do
        click_link "Admin Creation"
        expect(page).to have_content "Please enter the new admin's email below!"
    end
    
    it "password request link works" do
        click_link "Password Requests"
        expect(page).to have_content "Password Reset Requests"
    end
    
    it "disable mentor page link works" do
        click_link "Disable Mentor Page"
        expect(page).to have_content "Activate Mentor Page"
    end
    
    it "activate mentor page link works" do
        click_link "Activate Mentor Page"
        expect(page).to have_content "Disable Mentor Page"
    end
    
    it "allows user to logout" do
        click_link "Logout"
        expect(page).to have_content "Login"
    end
    
    it "goes to its mentor profile" do
        click_link "Access Mentor Page"
        click_link "Profile"
        expect(page).to have_content "admin@test.com"
    end
    
    it "allows admin ceation" do
        click_link "Admin Creation"
        fill_in "email", with: "jmhunt1@sheffield.ac.uk"
        click_button "Add"
        click_button "Yes"
        expect(page).not_to have_content "jmhunt1@sheffield.ac.uk"
    end
     
end