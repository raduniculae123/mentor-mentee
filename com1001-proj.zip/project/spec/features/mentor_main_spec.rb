require_relative "../spec_helper"

describe "mentor main page" do
    
    before(:each) do
        test_mentor_sign_in("mentor1", "mentor1")
    end
 
    #Testing features
    it "is accessible from profile" do
        visit "profile"
        click_link "Main"
        expect(page).to have_content "Hello mentor1"
    end
    
    it "profile link works" do
        click_link "Profile"
        expect(page).to have_content "User Profile"
    end
    
    it "allows user to logout" do
        click_link "Logout"
        expect(page).to have_content "Login"
    end
    
    #Testing accepting and declining requests
    it "allows accepting a request" do
        visit "/logout"
        test_mentee_sign_in("mentee2", "mentee2")
        visit "/mentee"
        find('table').find('a[href$="/request?id=1"]').click
        visit "/logout"
        test_mentor_sign_in("mentor1", "mentor1")
        visit "/mentor"
        find('table').find('a[href$="/accept-request?id=2"]').click
        expect(page).to have_content "Mentees"
    end
    
    it "allows canceling a request" do
        visit "/logout"
        test_mentee_sign_in("mentee1", "mentee1")
        visit "/mentee"
        find(:xpath, "//a[@href='/request?id=1']").click
        visit "/logout"
        test_mentor_sign_in("mentor1", "mentor1")
        visit "/mentor"
        find(:xpath, "//a[@href='/decline-request?id=1']").click
        expect(page).to have_content "No Mentee Requests"
    end
    
    
    
end