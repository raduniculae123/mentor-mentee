require_relative "../spec_helper"

describe "mentee sign in page" do
 
    #Testing features
    it "is accessible from mentor sign in" do
        visit "/sign-in-mentor"
        click_link "Mentee"
        expect(page).to have_content "Mentee"
    end
    
    #Testing correct inputs
    it "allows sign in for test user" do
        test_mentee_sign_in("mentee1", "mentee1")
        expect(page).to have_content "Hello mentee1"
    end
    
    #Testing incorrect inputs
    #Blank inputs
    it "will not allow sign in with no details" do
        test_mentee_sign_in("", "")
        expect(page).to have_content "Login"
    end
    
    it "will not allow sign in with blank username" do
        test_mentee_sign_in("", "mentee1")
        expect(page).to have_content "Login"
    end
    
    it "will not allow sign in with blank password" do
        test_mentee_sign_in("mentee1", "")
        expect(page).to have_content "Login"
    end
    
    #Incorrect inputs
    it "will not allow sign in with incorrect username, blank password" do
        test_mentee_sign_in("username", "")
        expect(page).to have_content "Login"
    end
    
    it "will not allow sign in with incorrect username, incorrect password" do
        test_mentee_sign_in("username", "password")
        expect(page).to have_content "Username/Password combination incorrect"
    end
    
    it "will not allow sign in with blank username, incorrect password" do
        test_mentee_sign_in("", "password")
        expect(page).to have_content "Login"
    end
    
    it "will not allow sign in with incorrect username, correct password" do
        test_mentee_sign_in("username", "mentee1")
        expect(page).to have_content "Username/Password combination incorrect"
    end
    
    it "will not allow sign in with correct username, incorrect password" do
        test_mentee_sign_in("mentee1", "password")
        expect(page).to have_content "Username/Password combination incorrect"
    end
    
end