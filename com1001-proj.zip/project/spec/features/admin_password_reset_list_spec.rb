require_relative "../spec_helper"

describe "admin password reset list page" do
    
    before(:each) do
        send_pass_reset_req("mentee1@test.com")
        send_pass_reset_req("mentor1@test.com")
        test_admin_sign_in("admin", "admin")
        click_link "Password Requests"
    end
    
    after(:each) do
        clear_database
        add_test_data
    end
    
    it "tests accepting a mentee password reset" do
        find('table').find('a[href$="/admin-reset-password?id=1&user_type=Mentee"]').click
        expect(page).to have_content "True"
    end
    
    it "tests accepting a mentor password reset" do
        find('table').find('a[href$="/admin-reset-password?id=1&user_type=Mentor"]').click
        expect(page).to have_content "True"
    end
     
end