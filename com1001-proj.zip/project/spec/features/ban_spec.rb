require_relative "../spec_helper"

describe "banning functionality: " do
       
    # Mentor Banning
    it "banning a mentor account" do
        test_mentee_sign_in("mentee1", "mentee1")
        click_link "mentor1"
        click_link "Report"
        find('input[name="submit"]').click
        click_link "Logout"
        test_admin_sign_in("admin", "admin")
        click_link "Reports"
        click_link "Yes"
        click_link "Main"
        click_link "Banned List"
        expect(page).to have_content "Unban"
    end
    
    it "banned mentor account login" do
        test_mentor_sign_in("mentor1", "mentor1")
        expect(page).to have_content "You are Banned"
    end
    
    it "unbanning a mentor account" do
        test_admin_sign_in("admin", "admin")
        click_link "Banned List"
        click_link "Unban"
        click_link "Logout"
        test_mentor_sign_in("mentor1", "mentor1")
        expect(page).to have_content "Hello mentor1"
    end
    
    # Mentee Banning
    it "banning a mentee account" do
        test_mentee_sign_in("mentee1", "mentee1")
        find(:xpath, "//a[@href='/request?id=1']").click
        click_link "Logout"
        test_mentor_sign_in("mentor1", "mentor1")
        click_link "mentee1"
        click_link "Report"
        find('input[name="submit"]').click
        click_link "Logout"
        test_admin_sign_in("admin", "admin")
        click_link "Reports"
        click_link "Yes"
        click_link "Main"
        click_link "Banned List"
        expect(page).to have_content "Unban"
    end
    
    it "banned mentee account login" do
        test_mentee_sign_in("mentee1", "mentee1")
        expect(page).to have_content "You are Banned"
    end
    
    it "unbanning a mentee account" do
        test_admin_sign_in("admin", "admin")
        click_link "Banned List"
        click_link "Unban"
        click_link "Logout"
        test_mentee_sign_in("mentee1", "mentee1")
        click_link "Cancel Request"
        expect(page).to have_content "Hello mentee1"
    end
    
    # Declining a report
    it "decling a report request" do
        test_mentee_sign_in("mentee1", "mentee1")
        click_link "mentor1"
        click_link "Report"
        find('input[name="submit"]').click
        click_link "Logout"
        test_admin_sign_in("admin", "admin")
        click_link "Reports"
        click_link "No"
        click_link "Main"
        click_link "Banned List"
        expect(page).to have_content "No Banned Mentors Found"
    end
end