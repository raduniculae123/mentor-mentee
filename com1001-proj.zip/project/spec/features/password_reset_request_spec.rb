require_relative "../spec_helper"

describe "pasword reset page" do
    
    it "Sends the request as mentee" do
        send_pass_reset_req ("mentee1@test.com")
        request = Request[1]
        expect(request.type).to eq("password_reset")
    end
    
    it "Sends the request as mentor" do
        send_pass_reset_req ("mentor1@test.com")
        request = Request[2]
        expect(request.type).to eq("password_reset")
    end
end
            