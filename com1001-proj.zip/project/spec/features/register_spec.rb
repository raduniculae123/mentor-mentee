require_relative "../spec_helper"

describe "register page" do
    
    #Testing correct inputs mentee
    it "allows register for test mentee" do
        test_register_page("mentee3@test.com", "mentee3", "mentee3", "Mentee")
        expect(page).to have_content "Login"
    end
    
    #Testing correct inputs mentor
    it "allows register for test mentor" do
        test_register_page("mentor3@test.com", "mentor3", "mentor3", "Mentor")
        expect(page).to have_content "Login"
    end
    
    #Testing incorrect inputs
    #Blank inputs
    #mentee 
    it "blocks register for blank mentee + email" do
        test_register_page("mentee3@test.com", "", "", "Mentee")
        expect(page).to have_content "Registration"
    end
    
    it "blocks register for blank mentee + username" do
        test_register_page("","mentee3", "", "Mentee")
        expect(page).to have_content "Registration"
    end
    
    #mentor
    it "blocks register for blank mentor + email" do
        test_register_page("mentor3@test.com", "", "", "Mentor")
        expect(page).to have_content "Registration"
    end
    
    it "blocks register for blank mentor + username" do
        test_register_page("","mentor3", "", "Mentor")
        expect(page).to have_content "Registration"
    end
    
    #Incorrect inputs
    #mentee
    #it "blocks register for incorrect email mentee" do
    #    test_register_page("email", "", "", "Mentee")
    #    expect(page).to have_content "Registration"
    #end
    
    #mentor
    #it "blocks register for incorrect email mentor" do
    #    test_register_page("email", "", "", "Mentor")
    #    expect(page).to have_content "Registration"
    #end   
end