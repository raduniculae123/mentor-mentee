require_relative "../spec_helper"

describe "admin sign in page" do
 
    #Testing features
    it "is accessible from mentee sign in" do
        visit "/sign-in-mentee"
        click_link "Admin"
        expect(page).to have_content "Admin"
    end
    
    #Testing correct inputs
    it "allows sign in for test user" do
        test_admin_sign_in("admin", "admin")
        expect(page).to have_content "Reports"
    end
    
    #Testing incorrect inputs
    #Blank inputs
    it "will not allow sign in with no details" do
        test_admin_sign_in("", "")
        expect(page).to have_content "Login"
    end
    
    it "will not allow sign in with blank username" do
        test_admin_sign_in("", "admin")
        expect(page).to have_content "Login"
    end
    
    it "will not allow sign in with blank password" do
        test_admin_sign_in("admin", "")
        expect(page).to have_content "Login"
    end
    
    #Incorrect inputs
    it "will not allow sign in with incorrect username, blank password" do
        test_admin_sign_in("username", "")
        expect(page).to have_content "Login"
    end
    
    it "will not allow sign in with incorrect username, incorrect password" do
        test_admin_sign_in("username", "password")
        expect(page).to have_content "Username/Password combination incorrect"
    end
    
    it "will not allow sign in with blank username, incorrect password" do
        test_admin_sign_in("", "password")
        expect(page).to have_content "Login"
    end
    
    it "will not allow sign in with incorrect username, correct password" do
        test_admin_sign_in("username", "admin")
        expect(page).to have_content "Username/Password combination incorrect"
    end
    
    it "will not allow sign in with correct username, incorrect password" do
        test_admin_sign_in("admin", "password")
        expect(page).to have_content "Username/Password combination incorrect"
    end
    
end

describe "admin creation" do
    
    it "works with correct inputs" do 
        visit "/admin-register61646d696e2d7265676973746572"
        fill_in "mail", with: "admin2@test.com"
        fill_in "username", with: "admin2"
        fill_in "psw", with: "admin2"
        click_button("register")
        click_link "Admin"
        test_admin_sign_in("admin2","admin2")
        click_link "Reports"
        expect(page).to have_content "Reports"
    end
    
end