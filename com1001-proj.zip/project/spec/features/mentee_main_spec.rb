require_relative "../spec_helper"

describe "mentee main page" do
    
    before(:each) do
        test_mentee_sign_in("mentee1", "mentee1")
    end
 
    #Testing features
    it "is accessible from profile" do
        visit "profile"
        click_link "Main"
        expect(page).to have_content "Hello mentee1"
    end
    
    it "profile link works" do
        click_link "Profile"
        expect(page).to have_content "User Profile"
    end
    
    it "allows user to logout" do
        click_link "Logout"
        expect(page).to have_content "Login"
    end
    
    #Testing mentor requesting
    it "allows requesting a mentor" do
        find('table').find('a[href$="/request?id=1"]').click
        expect(page).to have_content "Pending Request"
    end
    
    it "allows canceling a request" do
        click_link "Cancel Request"
        expect(page).to have_content "Available Mentors"
    end
    
    it "allows canceling a connected mentor" do
        find('table').find('a[href$="/request?id=1"]').click
        test_mentor_sign_in("mentor1","mentor1")
        find('table').find('a[href$="/accept-request?id=1"]').click
        visit "/logout"
        test_mentee_sign_in("mentee1", "mentee1")
        find('table').find('a[href$="/cancel-mentor"]').click
        expect(page).to have_content "Available Mentors"
    end
           
end

describe "filtering on Mentee Page" do
    
    after(:each) do
        clear_database
        add_test_data
    end
    
    before(:each) do
        test_mentee_sign_in("mentee1", "mentee1")
    end
    
    it "filters by name from A to F" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"jacob", "psw"=>"jacob" , "name" => "adam", "instruments" => "Guitar"})
        check "name_filter_A-F"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "adam"
    end
    
    it "filters by name from G to L" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"jacob", "psw"=>"jacob" , "name" => "Gulia", "instruments" => "Guitar"})
        check "name_filter_G-L"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Gulia"
    end
    
    it "filters by name from M to R" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"jacob", "psw"=>"jacob" , "name" => "Mary", "instruments" => "Guitar"})
        check "name_filter_M-R"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Mary"
    end
    
    it "filters by name from S to Z" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"jacob", "psw"=>"jacob" , "name" => "Stylianos", "instruments" => "Guitar"})
        check "name_filter_S-Z"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Stylianos"
    end
    
    it "filters by username A to F" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"adam", "psw"=>"jacob" , "name" => "adam", "instruments" => "Guitar"})
        check "username_filter_A-F"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "adam"
    end
    
    it "filters by username G to L" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Garry", "psw"=>"jacob" , "name" => "adam", "instruments" => "Guitar"})
        check "username_filter_G-L"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Garry"
    end
    
    it "filters by username M to R" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Garry", "psw"=>"jacob" , "name" => "adam", "instruments" => "Guitar"})
        check "username_filter_M-R"
        click_button("Filter")
        expect(page).to have_content "mentor1"
        expect(page).not_to have_content "Garry"
    end
    
    it "filters by username S to Z" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Guitar"})
        check "username_filter_S-Z"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Guitar" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Guitar"})
        check "instrument_filter_guitar"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Piano" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Piano"})
        check "instrument_filter_piano"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Drums" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Drums"})
        check "instrument_filter_drums"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Trumpet" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Trumpet"})
        check "instrument_filter_trumpet"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Violin" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Violin"})
        check "instrument_filter_violin"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Saxophone" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Saxophone"})
        check "instrument_filter_saxophone"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Flute" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Flute"})
        check "instrument_filter_flute"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Cello" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Cello"})
        check "instrument_filter_cello"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Clarinet" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Clarinet"})
        check "instrument_filter_clarinet"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Harp" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Harp"})
        check "instrument_filter_harp"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by instrumnent Bass" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Bass"})
        check "instrument_filter_bass"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by name and instrumnent" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Bass"})
        check "instrument_filter_bass"
        check "name_filter_A-F"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by username and instrumnent" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Bass"})
        check "username_filter_S-Z"
        check "instrument_filter_bass"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by username and name" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Bass"})
        check "username_filter_S-Z"
        check "name_filter_A-F"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
    
    it "filters by username and name and instrumnent" do
        createMentor({ "mail"=>"jacob@test.com", "username"=>"Seb", "psw"=>"jacob" , "name" => "adam", "instruments" => "Bass"})
        check "username_filter_S-Z"
        check "instrument_filter_bass"
        check "name_filter_A-F"
        click_button("Filter")
        expect(page).not_to have_content "mentor1"
        expect(page).to have_content "Seb"
    end
end