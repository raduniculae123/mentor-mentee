#Testing request model
RSpec.describe Request do
    
    describe "#complete" do
        it "Marks the request complete" do
            request = Request.new
            request.complete
            expect(request.completed).to eq(1)
        end
    end
    
end