#Testing mentee model
RSpec.describe Mentor do
     
    #Methods
    describe "#ban" do
        it "bans the mentor" do
            testMentor = Mentor.new
            testMentor.ban
            expect(testMentor.active).to eq(0)
        end
    end
    
    describe "#unban" do
        it "bans the mentor" do
            testMentor = Mentor.new
            testMentor.unban
            expect(testMentor.active).to eq(1)
        end
    end
    
    describe "#id_exists?" do
        it "check for mentor with id" do
            expect(Mentor.id_exists?(1)).to eq(true)
        end

        it "check for mentor without id" do
            expect(Mentor.id_exists?(99)).to eq(false)
        end
    end
    
    describe "#mentor_enable" do
        it "sets an admin to a mentor also" do
            testMentor = Mentor.new
            testMentor.mentor_enable
            expect(testMentor.mentor).to eq(1)
        end
    end
    
    describe "#mentor_disable" do
        it "stops mentor being admin" do
            testMentor = Mentor.new
            testMentor.mentor_disable
            expect(testMentor.mentor).to eq(0)
        end
    end
end
