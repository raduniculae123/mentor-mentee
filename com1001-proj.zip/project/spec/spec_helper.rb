# Configure coverage logging
require "simplecov"
SimpleCov.start do
    add_filter "/spec/"
end
SimpleCov.coverage_dir "coverage"

# Ensure we use the test database
ENV["APP_ENV"] = "test"

# load the app
require_relative "../app"

# Configure Capybara
require "capybara/rspec"
Capybara.app = Sinatra::Application

# Configure RSpec
def app
    Sinatra::Application
end
RSpec.configure do |config|
    config.include Capybara::DSL
    config.include Rack::Test::Methods
end

#Create test data
def add_test_data
    createMentee({ "mail"=>"mentee1@test.com", "username"=>"mentee1", "psw"=>"mentee1" })
    createMentee({ "mail"=>"mentee2@test.com", "username"=>"mentee2", "psw"=>"mentee2" })
    createMentor({ "mail"=>"mentor1@test.com", "username"=>"mentor1", "psw"=>"mentor1" })
    createMentor({ "mail"=>"mentor2@test.com", "username"=>"mentor2", "psw"=>"mentor2" })
    createAdmin({ "mail"=>"admin@test.com", "username"=>"admin", "psw"=>"admin"})
end

#add new mentee to database
def createMentee(params)
    @mentee = Mentee.new
    @mentee.load(params)
    @mentee.save_changes
end

#add new mentor to database
def createMentor(params)
    @mentor = Mentor.new
    @mentor.load(params)
    @mentor.save_changes
end

def createAdmin(params)
    @admin = Mentor.new
    @admin.load(params)
    @admin.admin_completion
    @admin.save_changes
end

# fill in mentee signin
def test_mentee_sign_in (username, password)
    visit "/sign-in-mentee"
    fill_in "username", with: username
    fill_in "psw", with: password
    click_button
end

# fill in mentor signin
def test_mentor_sign_in (username, password)
    visit "/sign-in-mentor"
    fill_in "username", with: username
    fill_in "psw", with: password
    click_button
end

# fill in admin signin
def test_admin_sign_in (username, password)
    visit "/sign-in-admin"
    fill_in "username", with: username
    fill_in "psw", with: password
    click_button
end

# fill in register
def test_register_page (email, username, password, user)
    visit "/register"
    fill_in "mail", with: email
    fill_in "username", with: username
    fill_in "psw", with: password
    choose "user", with: user
    click_button("register")
end

#def request(mentor)
#    puts "pls"
#    visit "/logout"
#    test_mentee_sign_in("mentee2", "mentee2")
#    visit "/mentee"
#    save_page
#    puts "hi"
#    find('table').find('a[href$="/request?id=1"]').click
#    visit "/logout"
#    test_mentor_sign_in(mentor, mentor)
#    visit "/mentor"
#end

def send_pass_reset_req (email)
    visit "/reset-password"
    fill_in "mail", with: email
    click_button
end

# clear out the database
def clear_database
    DB.from("mentees").delete
    DB.from("mentors").delete
    DB.from("requests").delete
end

# ensure we're always starting from a clean database
clear_database
add_test_data