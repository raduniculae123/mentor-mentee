require "sinatra"
require "sinatra/reloader"
require "require_all"

set :bind, "0.0.0.0"

enable :sessions
set :session_secret, "$g]Rd2M/WbJ`~~<GZWdH@Fm'ESk2_gckCtLJJkySYG"

require_relative "db/db"

include ERB::Util

require_all "controllers"
require_all "models"
require_all "helpers"