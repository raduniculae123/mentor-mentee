get "/banned" do
    erb :banned
end

get "/ban-user" do
    id = params["id"]
    userType = params["userType"]
    reportId = params["reportId"]
    
    @report = Request[reportId]
    @report.complete
    @report.save_changes
    
    if userType == "Mentee" 
        @mentee = Mentee[id]
        @mentee.ban
        @mentee.save_changes
    elsif userType == "Mentor"
        @mentor = Mentor[id]
        @mentor.ban
        @mentor.save_changes
    end
    
    redirect "/admin-reports"
end

get "/ban-decline" do 
    id = params["id"]
    @report = Request[id]
    @report.complete
    @report.save_changes
    
    redirect "/admin-reports"
end

get "/unban" do
    id = params["id"]
    userType = params["userType"]
    
    if userType == "Mentee"
        @mentee = Mentee[id]
        @mentee.unban
        @mentee.save_changes
    elsif userType == "Mentor"
        @mentor = Mentor[id]
        @mentor.unban
        @mentor.save_changes
    end
    
    redirect "/admin-banned-list"
end