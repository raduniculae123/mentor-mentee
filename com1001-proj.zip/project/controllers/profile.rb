get "/profile" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    @userType = session[:userType] 
    
    if @userType == "Mentee"
        @mentee = Mentee.where(Sequel.like(:username, "%#{session[:user_logged]}"))
        
        @name = @mentee.get(:name)
        @mail = @mentee.get(:mail)
        @date_of_birth = @mentee.get(:date_of_birth)
        @study_year = @mentee.get(:study_year)
        @course = @mentee.get(:course)
        @instrument = @mentee.get(:instrument)
        
    elsif @userType == "Mentor"
        @mentor = Mentor.where(Sequel.like(:username, "%#{session[:user_logged]}"))
        
        @name = @mentor.get(:name)
        @mail = @mentor.get(:mail)
        @date_of_birth = @mentor.get(:date_of_birth)
        @gender = @mentor.get(:gender)
        @yearOfGrad = @mentor.get(:graduated_uni)
        @instruments = @mentor.get(:instruments)
        @experience = @mentor.get(:experience)
        
    elsif @userType == "adminMentor"
        @mentor = Mentor.where(Sequel.like(:username, "%#{session[:user_logged]}"))
        
        @name = @mentor.get(:name)
        @mail = @mentor.get(:mail)
        @date_of_birth = @mentor.get(:date_of_birth)
        @gender = @mentor.get(:gender)
        @yearOfGrad = @mentor.get(:graduated_uni)
        @instruments = @mentor.get(:instruments)
        @experience = @mentor.get(:experience)
    end
    
    erb :profile
end

get "/mentee-profile" do
    @userType = session[:userType]
    
    id = params["id"]
    @mentee = Mentee[id] if Mentee.id_exists?(id) 
    erb :mentee_profile
end

get "/mentor-profile" do
    @userType = session[:userType]
    
    id = params["id"]
    @mentor = Mentor[id] if Mentor.id_exists?(id)
    erb :mentor_profile
end

get "/report" do
    @userType = session[:userType]
    @report = Request.new
    @date = Date.today
    
    id = params["id"]
    if @userType == "Mentee"
        @reportUType = "Mentor"
        @reportedUser = Mentor[id] if Mentor.id_exists?(id)
    elsif @userType == "Mentor"
        @reportUType = "Mentee"
        @reportedUser = Mentee[id] if Mentee.id_exists?(id)
    end
    
    erb :report
end

post "/report" do
    @userType = session[:userType]
    
    @report = Request.new
    @report.load(params)
    @report.save_changes
    
    if @userType == "Mentee"
        redirect "/mentee"
    elsif @userType == "Mentor"
        redirect "/mentor"
    end
end
