get "/register" do
  @user = params["user"]
  @account = Mentee.new
  erb :register
end



post "/register" do
   
  @error = nil
   
  #Mentee registration into the database
  @user = params["user"]
  if @user == "Mentee"
      @account = Mentee.new
      @account.load(params)
      
      #Checks if account already exists
      if !@account.in_db?
      @account.save_changes
      redirect "/sign-in-mentee"
      else @error = "Same mail or username mentee"
      end
  end
  
  #Mentor registration into the database
  if @user == "Mentor"
      @account = Mentor.new
      @account.load(params)
      
      #Checks if account already exists
      if !@account.in_db?
      @account.save_changes
      redirect "/sign-in-mentee"
      else @error = "Same mail or username mentor"
      end
  end
    
  erb :register
end

get "/admin-register61646d696e2d7265676973746572" do
    @user = params["user"]
    @account = Mentee.new
    
    erb :admin_register
end
    
    #Admin registration into the database
post "/admin-register61646d696e2d7265676973746572" do
    @account = Mentor.new
    @account.load(params)
    @account.admin_completion
    @account.save_changes
    redirect "/sign-in-mentor"
end