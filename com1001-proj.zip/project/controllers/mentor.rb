get "/mentor" do
    redirect "/banned" unless Mentor[session[:userID]].active == 1
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    
    @userType = session[:userType]
    
    user_logged = session[:user_logged]
    @user = user_logged
    
    @request_search = Mentor[session[:userID]].id
    @mentee_accepts = Mentee.where(Sequel.like(:mentor_email, "%#{@request_search}"))
    @mentee_requests = Mentee.where(Sequel.like(:request_username, "%#{@request_search}"))

    #notification
    if Mentor[session[:userID]].name.nil? || Mentor[session[:userID]].name == "" || Mentor[session[:userID]].instruments.nil? || Mentor[session[:userID]].instruments == ""
        @notice_text = "Please update your information in the profile page"
    end
    erb :mentor_main
end

get "/accept-request" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    redirect "/banned" unless Mentor[session[:userID]].active == 1
    
    @user = Mentor[session[:userID]]
    menteeID = params["id"]
    @mentee = Mentee[menteeID]
    @mentee.mentor_email = @user.id
    @mentee.delete_request
    @mentee.save_changes
    redirect "/mentor"
end

get "/decline-request" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    redirect "/banned" unless Mentor[session[:userID]].active == 1
    
    menteeID = params["id"]
    @mentee = Mentee[menteeID]
    @mentee.delete_request
    @mentee.save_changes
    redirect "/mentor"
end
