get "/mentee" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    redirect "/banned" unless Mentee[session[:userID]].active == 1

     #notification
    if Mentee[session[:userID]].name.nil? || Mentee[session[:userID]].name == "" || Mentee[session[:userID]].instrument.nil? || Mentee[session[:userID]].instrument == ""
      @notice_text = "Please update your information in the profile page"
    end
    
    user_logged = session[:user_logged]
    @user = user_logged
    
    @userType = session[:userType]
    
    @request_mentor = Mentor.where(mentor: 1)
    
    @r_mentor_exist = Mentee[session[:userID]].requested_mentor_exists
    
    @connected_mentor = Mentor[Mentee[session[:userID]].mentor_email]
    
    @pending_request = Mentor[Mentee[session[:userID]].request_username]

    @requested = session[:requested] && @r_mentor_exist
    
    #Filtering
    
    @username_filter_A_F = params.fetch("username_filter_A-F", "").strip
    @username_filter_G_L = params.fetch("username_filter_G-L", "").strip
    @username_filter_M_R = params.fetch("username_filter_M-R", "").strip
    @username_filter_S_Z = params.fetch("username_filter_S-Z", "").strip
    @usernames = Mentor.pluck(:username)
    
    #Checks if a username filter is selected
    if @username_filter_A_F == "A-F" or @username_filter_G_L == "G-L" or @username_filter_M_R == "M-R" or @username_filter_S_Z == "S-Z"
        username_checked = true
    else
        username_checked = false
    end
    
    #The following loops put every username in the database that starts with the letters into the usrename_filter_array chosen by the filter checkboxes 
    @username_filter_array = Array.new
    if @username_filter_A_F == "A-F"
        ("a".."f").each do |l|
            @usernames.each do |u|
                @username_filter_array.push u if u.starts_with?(l)
            end
        end
        ("A".."F").each do |l|
            @usernames.each do |u|
                @username_filter_array.push u if u.starts_with?(l)
            end
        end
    end
    
    if @username_filter_G_L == "G-L"
        ("g".."l").each do |l|
            @usernames.each do |u|
                @username_filter_array.push u if u.starts_with?(l)
            end
        end
        ("G".."L").each do |l|
            @usernames.each do |u|
                @username_filter_array.push u if u.starts_with?(l)
            end
        end
    end
    
    if @username_filter_M_R == "M-R"
        ("m".."r").each do |l|
            @usernames.each do |u|
                @username_filter_array.push u if u.starts_with?(l)
            end
        end
        ("M".."R").each do |l|
            @usernames.each do |u|
                @username_filter_array.push u if u.starts_with?(l)
            end
        end
    end
    
    if @username_filter_S_Z == "S-Z"
        ("s".."z").each do |l|
            @usernames.each do |u|
                @username_filter_array.push u if u.starts_with?(l)
            end
        end
        ("S".."Z").each do |l|
            @usernames.each do |u|
                @username_filter_array.push u if u.starts_with?(l)
            end
        end
    end

    @name_filter_A_F = params.fetch("name_filter_A-F", "").strip
    @name_filter_G_L = params.fetch("name_filter_G-L", "").strip
    @name_filter_M_R = params.fetch("name_filter_M-R", "").strip
    @name_filter_S_Z = params.fetch("name_filter_S-Z", "").strip
    @names = Mentor.pluck(:name)
    
    # checkes if a name filter has been selected
    if @name_filter_A_F == "A-F" or @name_filter_G_L == "G-L" or @name_filter_M_R == "M-R" or @name_filter_S_Z == "S-Z"
        name_checked = true
    else
        name_checked = false
    end
    
    #The following loops put every name in the database that starts with the letters into the name_filter_array chosen by the filter checkboxes 
    @name_filter_array = Array.new
    if @name_filter_A_F == "A-F"
        ("a".."f").each do |l|
            @names.each do |n|
                @name_filter_array.push n if n.starts_with?(l)
            end
        end
        ("A".."F").each do |l|
            @names.each do |n|
                @name_filter_array.push n if n.starts_with?(l)
            end
        end
    end
    
    if @name_filter_G_L == "G-L"
        ("g".."l").each do |l|
            @names.each do |n|
                @name_filter_array.push n if n.starts_with?(l)
            end
        end
        ("G".."L").each do |l|
            @names.each do |n|
                @name_filter_array.push n if n.starts_with?(l)
            end 
        end
    end
    
    if @name_filter_M_R == "M-R"
        ("m".."r").each do |l|
            @names.each do |n|
                @name_filter_array.push n if n.starts_with?(l)
            end
        end
        ("M".."R").each do |l|
            @names.each do |n|
                @name_filter_array.push n if n.starts_with?(l)
            end
        end
    end
    
    if @name_filter_S_Z == "S-Z"
        ("s".."z").each do |l|
            @names.each do |n|
                @name_filter_array.push n if n.starts_with?(l)
            end
        end
        ("S".."Z").each do |l|
            @names.each do |n|
                @name_filter_array.push n if n.starts_with?(l)
            end
        end
    end
    
    @instrument_filter_guitar = params.fetch("instrument_filter_guitar", "").strip
    @instrument_filter_piano = params.fetch("instrument_filter_piano", "").strip
    @instrument_filter_drums = params.fetch("instrument_filter_drums", "").strip
    @instrument_filter_trumpet = params.fetch("instrument_filter_trumpet", "").strip
    @instrument_filter_violin = params.fetch("instrument_filter_violin", "").strip
    @instrument_filter_saxophone = params.fetch("instrument_filter_saxophone", "").strip
    @instrument_filter_flute = params.fetch("instrument_filter_flute", "").strip
    @instrument_filter_cello = params.fetch("instrument_filter_cello", "").strip
    @instrument_filter_clarinet = params.fetch("instrument_filter_clarinet", "").strip
    @instrument_filter_harp = params.fetch("instrument_filter_harp", "").strip
    @instrument_filter_bass = params.fetch("instrument_filter_bass", "").strip
    
    #instrument_check initialised as false unless any of the filters are clicked, it becomes true below
    instrument_checked = false
    
    #The following loops put every instrument in the database into the instrument_filter_array chosen by the filter checkboxes 
    @instrument_filter_array = Array.new
    
    if @instrument_filter_guitar == "Guitar"
        @instrument_filter_array.push @instrument_filter_guitar
        instrument_checked = true
    end
    if @instrument_filter_piano == "Piano"
        @instrument_filter_array.push @instrument_filter_piano
        instrument_checked = true
    end
    if @instrument_filter_drums == "Drums"
        @instrument_filter_array.push @instrument_filter_drums
        instrument_checked = true
    end
    if @instrument_filter_trumpet == "Trumpet"
        @instrument_filter_array.push @instrument_filter_trumpet
        instrument_checked = true
    end
    if @instrument_filter_violin == "Violin"
        @instrument_filter_array.push @instrument_filter_violin
        instrument_checked = true
    end
    if @instrument_filter_saxophone == "Saxophone"
        @instrument_filter_array.push @instrument_filter_saxophone
        instrument_checked = true
    end
    if @instrument_filter_flute == "Flute"
        @instrument_filter_array.push @instrument_filter_flute
        instrument_checked = true
    end
    if @instrument_filter_cello == "Cello"
        @instrument_filter_array.push @instrument_filter_cello
        instrument_checked = true
    end
    if @instrument_filter_clarinet == "Clarinet"
        @instrument_filter_array.push @instrument_filter_clarinet
        instrument_checked = true
    end
    if @instrument_filter_harp == "Harp"
        @instrument_filter_array.push @instrument_filter_harp
        instrument_checked = true
    end
    if @instrument_filter_bass == "Bass"
        @instrument_filter_array.push @instrument_filter_bass
        instrument_checked = true
    end
        
    #using the above booleans which say if a filter was selected uses the arrays created to search through the database to display filtered results  
    @request_mentor = if !username_checked and !name_checked and !instrument_checked
                            @request_mentor.all
                      elsif username_checked and !name_checked and !instrument_checked
                            @request_mentor.where(username: @username_filter_array)
                      elsif name_checked and !username_checked and !instrument_checked
                            @request_mentor.where(name: @name_filter_array)
                      elsif instrument_checked and !username_checked and !name_checked
                            @request_mentor.where(instruments: @instrument_filter_array)
                      elsif name_checked and username_checked and !instrument_checked
                            @request_mentor.where(name: @name_filter_array).where(username: @username_filter_array)
                      elsif name_checked and instrument_checked and !username_checked
                            @request_mentor.where(name: @name_filter_array).where(instruments: @instrument_filter_array)
                      elsif username_checked and instrument_checked and !name_checked
                            @request_mentor.where(username: @username_filter_array).where(instruments: @instrument_filter_array)
                      else
                            @request_mentor.where(username: @username_filter_array).where(name: @name_filter_array).where(instruments: @instrument_filter_array)
                      end
    
    
    
    
    erb :mentee_main
end

#Creating a request of mentor email
get "/request" do
    session[:requested] = true
    id = params["id"]
    @user = Mentee[session[:userID]]
    @user.request(id)
    @user.save_changes
    redirect "/mentee"
end

#Deleting a request to a mentor
get "/delete-request" do
    session[:requested] = false
    @user = Mentee[session[:userID]]
    @user.delete_request
    @user.save_changes
    redirect "/mentee"
end

#Canceling an already accepted request
get "/cancel-mentor" do
    @user = Mentee[session[:userID]]
    @user.mentor_email = nil
    @user.save_changes
    redirect "/mentee"
end
