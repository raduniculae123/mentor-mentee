get "/admin" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    
    @userType = session[:userType]
    if Mentor[session[:userID]].mentor == 1
        @mentor_link = "/mentor" 
        session[:userType] = "adminMentor"
    end
    
    erb :admin_main
end

get "/admin-reports" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    
    @reports = Request.where(type: "report")
    
    erb :admin_reports
end

get "/admin-mentee-list" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    
    @mentees = Mentee.all
    erb :admin_mentee_list
end

get "/admin-mentor-list" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    
    @mentors = Mentor.all
    erb :admin_mentor_list
end

get "/admin-banned-list" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    
    @bannedMentees = Mentee.where(active: "0")
    @bannedMentors = Mentor.where(active: "0")
    
    erb :admin_banned_list
end

get "/admin-creation" do
    redirect "sign-in-mentee" unless session[:logged_in]==true
    
    erb :admin_creation
end

def hostname
  # Prefer the value in Codio"s environment variable...
  hostname = ENV["hostname"]
  return hostname unless hostname.nil?

  # ... but use Ruby's method if for whatever
  # reason the environment variable is not set
  Socket.gethostname
end

post "/admin-creation" do
    @email = params["email"]
    #sends an email to a specific person with a link to register as an admin
    send_mail(@email, "Admin Register Link", "Please click the link below to create an account as an admin for the department of Music Mentoring System. Click this link https://#{hostname}-4567.codio.io/admin-register61646d696e2d7265676973746572")
    
    erb :admin_creation
end

#Password reset

get "/admin-password-reset-list" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    
    # list of password reset requests to display
    @requests = Request.where(Sequel.like(:type, "%#{'password_reset'}"))
    @mentees = Mentee.all
    @mentors = Mentor.all
    
    erb :admin_password_reset_list
end

# resets the password for the linked account
get "/admin-reset-password" do
    redirect "/sign-in-mentee" unless session[:logged_in]==true
    
    # check if mentee or other
    if params["user_type"] == "Mentee"
        @accountToReset = Mentee[params["id"]]
        @requests = Request.where(Sequel.like(:type, "%#{'password_reset'}", :user_type, "%{params['user_type']}"))
        @account = Mentee.all
    else
        @accountToReset = Mentor[params["id"]]
        @requests = Request.where(Sequel.like(:type, "%#{'password_reset'}", :user_type, "%{params['user_type']}"))
        @account = Mentor.all
    end
    
    #reset password
    @accountToReset.psw = "password"
    @accountToReset.save_changes
    #changes any request that fits in csase of multiple requests from one account
    @requests.each do |request|
        if request.user_id == @accountToReset.id and request.user_type == params["user_type"]
            request.complete
            request.save_changes
        end
    end
    
    #sends an email to notify the user of a password change
    send_mail(@accountToReset.mail, "Department of music password reset", 
        'Your password for the department of music tutoring system has been reset to "password". Please log in and reset to a more secure password.')
    
    @mentees = Mentee.all
    @mentors = Mentor.all
    
    erb :admin_password_reset_list
end

get "/activate-mentor" do
    @admin = Mentor[session[:userID]]
    @admin.mentor_enable
    @admin.save_changes
    

    redirect "/admin"
end

get "/disable-mentor" do
    @admin = Mentor[session[:userID]]
    @admin.mentor_disable
    @admin.save_changes
    
    redirect "/admin"
end
