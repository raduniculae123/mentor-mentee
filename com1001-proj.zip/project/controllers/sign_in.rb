get "/" do 
    redirect "/sign-in-mentee"
end

get "/sign-in-mentee" do
    @mentee = Mentee.new
    erb :sign_in_page
end

post "/sign-in-mentee" do
    @mentee = Mentee.new
    @mentee.load(params)
    @error = nil
    session[:logged_in] = false
        
    if @mentee.valid? # check if mentee is valid
        if @mentee.exist? #checks if user exists and that passwords match too
            session[:logged_in] = true #used to now if mentee is signed in
            session[:user_logged] = @mentee.user
            
            session[:userType]="Mentee"
            
            @userDetails = Mentee.where(Sequel.like(:username, "%#{session[:user_logged]}"))
            session[:userID]= @userDetails.get(:id) #stores the id of the user to get the details afterwards
            
            @r_mentor_exist = @userDetails.get(:request_username) #checks if there is a request to a mentor already then stores the result in a session cookie
            if @r_mentor_exist == ""
                session[:requested] = false 
            else
                session[:requested] = true
            end
            
            redirect "/mentee"
        else
            @error = "Username/Password combination incorrect"
        end
    else
        @error = "Please correct the information below"
    end
    
    erb :sign_in_page
end
get "/sign-in-mentor" do
    @mentor = Mentor.new
    erb :sign_in_page_mentor
end

post "/sign-in-mentor" do
    @mentor = Mentor.new
    @mentor.load(params)
    @error = nil
    session[:logged_in] = false
    
    if @mentor.valid?  # check if mentor is valid
        if @mentor.exist? #checks if user exists and that passwords match too
            session[:logged_in] = true #used to now if mentee is signed in
            session[:user_logged] = @mentor.user
            
            session[:userType]="Mentor"
            @userDetails = Mentor.where(Sequel.like(:username, "%#{session[:user_logged]}"))
            session[:userID]= @userDetails.get(:id) #stores the id of the user to get the details afterwards
            
            redirect "/mentor"
        else
            @error = "Username/Password combination incorrect"
        end
    else
        @error = "Please correct the information below"
    end
    
    erb :sign_in_page_mentor
end

get "/sign-in-admin" do
    @admin = Mentor.new
    erb :sign_in_page_admin
end

post "/sign-in-admin" do
    @admin = Mentor.new
    @admin.load(params)
    @admin.admin = 1
    @error = nil
    session[:logged_in] = false
    
    if @admin.valid? # check if mentor is valid
        if @admin.exist? #checks if user exists and that passwords match too
            if @admin.admin == 1 # checks if the user is an admin
                session[:logged_in] = true #used to now if mentee is signed in
                session[:user_logged] = @admin.user
                
                session[:userType]="Admin"
                @userDetails = Mentor.where(Sequel.like(:username, "%#{session[:user_logged]}"))
                session[:userID]= @userDetails.get(:id) #stores the id of the user to get the details afterwards
                
                redirect "/admin"
            end
        else
            @error = "Username/Password combination incorrect"
        end
    else
        @error = "Please correct the information below"
    end
    
    erb :sign_in_page_admin
end

#reset password

get "/reset-password" do
    @reset_email = nil
    @reset_request = Request.new
    erb :reset_password
end

# takes an email param and return a request for a password reset for linked account
post "/reset-password" do
    #gets email
    @reset_email = params[:mail].chomp
    @reset_request = Request.new
    # differentiate between mentee and mentor
    @resetUser = Mentee.where(Sequel.like(:mail, "%#{@reset_email}"))
    @reset_request.user_type = "Mentee"
    if @resetUser.blank?
        @resetUser = Mentor.where(Sequel.like(:mail, "%#{@reset_email}"))
        @reset_request.user_type = "Mentor"
    end
    #fill in details of request
    @reset_request.type ="password_reset"
    @reset_request.date = Date.today
    @reset_request.content = "Password reset request"
    @reset_request.user_id = @resetUser.first.id
    @reset_request.save_changes
    
    redirect "/"
end

#info input

get "/info-input-mentee" do
    @currentUser = Mentee[session[:userID]]
    erb :info_input_mentee
end

post "/info-input-mentee" do
    @currentUser = Mentee[session[:userID]]
    @currentUser.load(params)
    
    @currentUser.save_changes
    
    redirect "/profile"
end

get "/info-input-mentor" do
    @currentUser = Mentor[session[:userID]]
    erb :info_input_mentor
end

post "/info-input-mentor" do
    @currentUser = Mentor[session[:userID]]
    @currentUser.load(params)
    
    @currentUser.save_changes
    
    redirect "/profile"
end

get "/logout" do
   session["logged_in"] = false
   redirect "/sign-in-mentee"
end
    