# Team 15's Department of Music Tutoring Booking System
A program that allows three types of user: Mentee, Mentor and Admin. 
Mentees can login and request a suitable mentor for tutoring.
Mentors can accept any requests and see who they are tutoring.
Admins handle administrative services such as password reset, banning accounts and admin creation.
Admins can also opt in to be mentors and complete mentor functions.

### To install the project
Connect a terminal to the GitHub repository
In the terminal, you need to change to the directory:
cd ~/workspace/project

#### Install the gems:
run **bundle install**

### To run:
run **ruby app.rb**

Tip: Use Ctrl-c to stop the application

### To access the web page, open
http://beast-portal-4567.codio.io
(for Client Demo box)
##### For individual box:
http://box-domain-4567.codio.io
(where box-domain is your individual box domain found in the codio terminal)

### To run tests:
Be in project directory
cd ~/workspace/project
run **rspec**

#### Test Info:
Runs unit tests for models
Runs acceptance tests for each page