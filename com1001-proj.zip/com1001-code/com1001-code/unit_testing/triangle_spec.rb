require "rspec"
require_relative "triangle"

RSpec.describe do
    describe "#classify" do
        context "when given three numbers, 1 and 2 and 4" do
            it "returns 'scalene' " do
                expect(classify(2,3,4)).to eq('scalene')
            end
        end
        
        context "when given three numbers, 1 and 1 and 2" do
            it "returns 'isosceles' " do
                expect(classify(4,4,3)).to eq('isosceles')
            end
        end
        
        context "when given three numbers, 1 and 1 and 1" do
            it "returns 'equilateral' " do
                expect(classify(1,1,1)).to eq('equilateral')
            end
        end
        
        context "when given three numbers, 0 and 1 and 1" do
            it "returns 'invalid' " do
                expect(classify(0,1,1)).to eq('invalid')
            end
        end
        
        context "when given three numbers, -1 and 1 and 1" do
            it "returns 'invalid' " do
                expect(classify(-1,1,1)).to eq('invalid')
            end
        end
        
        context "when given three numbers, 5 and 1 and 1" do
            it "returns 'invalid' " do
                expect(classify(5,1,1)).to eq('invalid')
            end
        end
        
        context "when one side is a letter" do
          it "returns inavlid" do
            expect(classify(10,5,'h')).to eq("invalid")
          end
        end
        
        context "when ....." do
          it "returns 'isosceles'" do
            expect(classify(3,3,5)).to eq("isosceles")
          end
        end
        
    end
end
        
        
        
        
        
        
        
        
        
        