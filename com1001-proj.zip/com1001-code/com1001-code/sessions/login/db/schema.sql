CREATE TABLE users (
    username TEXT PRIMARY KEY,
    password TEXT
);
