get "/admin/login" do
  # ...
end

get "/admin/logout" do
  # ...
end
