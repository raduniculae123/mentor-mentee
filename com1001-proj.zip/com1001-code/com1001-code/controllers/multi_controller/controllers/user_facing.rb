get "/" do
  # ...
end

get "/list-products" do
  # ...
end
